public class Team {
    private String teamName;

    //Getters 
    public String getTeamN() {
        return teamName;
    }
    //Setters 
    public void setTeamN(String name) {
        teamName = name;
    }
    
    //Contructors
    public Team(String Name){
        teamName = Name;
    }
}
