public class DRData { // stands for Driver Race Data
    private String RaceName;
    private String RaceDate;
    private int Racepostion;




    DRData(String x, String y, int z){
        RaceName = x;
        RaceDate = y;
        Racepostion = z;
    }
}
